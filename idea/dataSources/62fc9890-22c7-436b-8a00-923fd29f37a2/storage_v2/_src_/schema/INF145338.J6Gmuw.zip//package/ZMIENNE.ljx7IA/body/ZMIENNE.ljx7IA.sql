create PACKAGE BODY Zmienne IS
 vLicznik NATURAL;
 Procedure ZwiekszLicznik IS
 BEGIN
    vLicznik := vLicznik + 1;
    DBMS_OUTPUT.PUT_LINE('Zwiększono');
 END ZwiekszLicznik;

 Procedure ZmniejszLicznik IS
 BEGIN
    vLicznik := vLicznik - 1;
    DBMS_OUTPUT.PUT_LINE('Zmniejszono');
 END ZmniejszLicznik;

 FUNCTION PokazLicznik
  RETURN NATURAL IS
     pWynik NATURAL;
 BEGIN
    pWynik := vLicznik;
    RETURN pWynik;
 END PokazLicznik;

 BEGIN
    vLicznik := 1;
    DBMS_OUTPUT.ENABLE(NULL);
    DBMS_OUTPUT.PUT_LINE('Zainicjalizowano');
END Zmienne;
/

