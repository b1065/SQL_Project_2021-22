create FUNCTION Silnia
 (pNumer IN NATURAL)
    RETURN NATURAL IS
    pWynik NATURAL;
BEGIN
    pWynik := 1;
    FOR i IN 1..pNumer LOOP
        pWynik := pWynik*i;
        END LOOP;
    RETURN pWynik;
END Silnia;
/

