create PACKAGE BODY IntZespoly IS
 Procedure DodajZespol(pID NATURAL, pNazwa VARCHAR,pAdres VARCHAR) IS
    exZduplikowaneID EXCEPTION;
    PRAGMA EXCEPTION_INIT (exZduplikowaneID,-00001);
 BEGIN
    DBMS_OUTPUT.ENABLE(NULL);
    INSERT INTO ZESPOLY (ID_ZESP, NAZWA, ADRES)
    VALUES (pID,pNazwa,pAdres);
    IF SQL%NOTFOUND THEN
        DBMS_OUTPUT.PUT_LINE('Nie udało się dodać zespołu!');
    END IF;
 EXCEPTION
     WHEN exZduplikowaneID THEN
        DBMS_OUTPUT.PUT_LINE('Zespół o podanym ID już istnieje!');
 END DodajZespol;

 Procedure UsunZespolID(pID NATURAL) IS
    exNiepoprawneID EXCEPTION;
 BEGIN
    DELETE
    FROM ZESPOLY
    WHERE ID_ZESP = pID;
    IF SQL%NOTFOUND THEN
        RAISE exNiepoprawneID;
    END IF;
 EXCEPTION
    WHEN exNiepoprawneID THEN
        DBMS_OUTPUT.PUT_LINE('Podano nieprawidłowe ID zespołu!');
 END UsunZespolID;

 Procedure UsunZespolNazwa(pNazwa VARCHAR) IS
     exNiepoprawnaNazwa EXCEPTION;
 BEGIN
    DELETE
    FROM ZESPOLY
    WHERE NAZWA = pNazwa;
    IF SQL%NOTFOUND THEN
        RAISE exNiepoprawnaNazwa;
    END IF;
 EXCEPTION
     WHEN exNiepoprawnaNazwa THEN
        DBMS_OUTPUT.PUT_LINE('Podano niepoprawną nazwę zespołu!');
 END UsunZespolNazwa;

 Procedure ModyfikujZespol(pID NATURAL, pNazwa VARCHAR, pAdres VARCHAR) IS
 BEGIN
    UPDATE ZESPOLY
    SET NAZWA = pNazwa, ADRES = pAdres
    WHERE ID_ZESP = pID;
    IF SQL%NOTFOUND THEN
        DBMS_OUTPUT.PUT_LINE('Nie udało się zmodyfikować zespołu!');
    END IF;
 END ModyfikujZespol;

 FUNCTION PokazID(pNazwa VARCHAR)
  RETURN NATURAL IS
    exNiepoprawnaNazwa EXCEPTION;
    PRAGMA EXCEPTION_INIT (exNiepoprawnaNazwa,100);
    pWynik NATURAL;
 BEGIN
    SELECT ID_ZESP
    INTO pWynik
    FROM ZESPOLY
    WHERE NAZWA = pNazwa;
    RETURN pWynik;
 EXCEPTION
     WHEN exNiepoprawnaNazwa THEN
        DBMS_OUTPUT.PUT_LINE('Podano niepoprawną nazwę zespołu!');
 END PokazID;

 FUNCTION PokazNazwe(pID NATURAL)
  RETURN VARCHAR IS
     exNiepoprawneID EXCEPTION;
     PRAGMA EXCEPTION_INIT (exNiepoprawneID,100);
     pWynik2 VARCHAR(100);
 BEGIN
    SELECT NAZWA
    INTO pWynik2
    FROM ZESPOLY
    WHERE ID_ZESP = pID;
    RETURN pWynik2;
  EXCEPTION
    WHEN exNiepoprawneID THEN
        DBMS_OUTPUT.PUT_LINE('Podano nieprawidłowe ID zespołu!');
 END PokazNazwe;

 FUNCTION PokazAdres(pID NATURAL)
  RETURN VARCHAR IS
     --exNiepoprawneID EXCEPTION;
     --PRAGMA EXCEPTION_INIT (exNiepoprawneID,-01403);
     pWynik VARCHAR(100);
 BEGIN
    SELECT ADRES
    INTO pWynik
    FROM ZESPOLY
    WHERE ID_ZESP = pID;
    RETURN pWynik;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Podano nieprawidłowe ID zespołu!');
 END PokazAdres;

END IntZespoly;
/

