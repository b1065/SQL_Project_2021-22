create view ZAROBKI as
SELECT p.id_prac, p.nazwisko, p.etat, p.placa_pod
FROM pracownicy p
WHERE p.placa_pod < (SELECT s.placa_pod FROM pracownicy s WHERE s.id_prac = p.id_szefa)
ORDER BY p.nazwisko
WITH CHECK OPTION
/

