create view ASYSTENCI (NAZWISKO, PLACA, STAZ) as
SELECT nazwisko, placa_pod+NVL(placa_dod,0), (DATE'2021-01-01' - zatrudniony) YEAR TO MONTH
FROM pracownicy
WHERE etat = 'ASYSTENT'
/

