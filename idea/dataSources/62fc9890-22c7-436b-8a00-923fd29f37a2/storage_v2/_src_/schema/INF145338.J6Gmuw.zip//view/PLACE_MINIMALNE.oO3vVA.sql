create view PLACE_MINIMALNE as
SELECT id_prac, nazwisko, etat, placa_pod
FROM pracownicy
WHERE placa_pod < 700
ORDER BY nazwisko
WITH CHECK OPTION
/

