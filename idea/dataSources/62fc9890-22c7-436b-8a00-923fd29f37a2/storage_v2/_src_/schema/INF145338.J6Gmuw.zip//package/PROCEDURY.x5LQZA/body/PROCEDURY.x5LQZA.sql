create PACKAGE BODY Procedury IS
    Procedure DodajKlienta(pImie VARCHAR, pNazwisko VARCHAR, pAdres VARCHAR) IS
    BEGIN
        INSERT INTO KLIENT(ID_KLIENTA, IMIE, NAZWISKO, ADRES)
        VALUES (NVL((SELECT MAX(ID_KLIENTA)+1 FROM KLIENT),1),pImie,pNazwisko,pAdres);
    END DodajKlienta;
    Procedure UsunKlienta(pID NUMBER) IS
    BEGIN
        DELETE
        FROM KLIENT
        WHERE ID_KLIENTA = pID;
    END UsunKlienta;
    Procedure ModyfikujKlienta(pID NUMBER, pImie VARCHAR, pNazwisko VARCHAR, pAdres VARCHAR) IS
    BEGIN
        UPDATE KLIENT
        SET IMIE = pImie, NAZWISKO = pNazwisko, ADRES = pAdres
        WHERE ID_KLIENTA = pID;
    END ModyfikujKlienta;
    Procedure DodajZamowienie(pKlient NUMBER, pKoszt NUMBER, pCzas INTERVAL DAY TO SECOND) IS
    BEGIN
        INSERT INTO ZAMOWIENIE(ID_ZAM, ID_KLIENTA, KOSZT, CENA, CZAS_REALIZACJI)
        VALUES (nr_zamowienia.nextval,pKlient,pKoszt,pKoszt*1.2,pCzas);
    END DodajZamowienie;
    Procedure ZmienStatusZamowienia(pID NUMBER, pStan VARCHAR) IS
    BEGIN
        UPDATE ZAMOWIENIE
        SET STAN = pStan
        WHERE ID_ZAM = pID;
    END ZmienStatusZamowienia;
    Procedure DodajZadanie(pZam NUMBER, pDanie NUMBER, pPrac NUMBER) IS
    BEGIN
        INSERT INTO ZADANIE(ID_ZAM, ID_PRAC, ID_PRZEPISU)
        VALUES (pZam, pPrac, pDanie);
    END DodajZadanie;
    Procedure ZmienStatusZadania(pZam NUMBER, pStan VARCHAR) IS
    BEGIN
        UPDATE ZADANIE
        SET STAN = pStan
        WHERE ID_ZAM = pZam;
    END ZmienStatusZadania;
    Procedure DodajDanie(pNazwa VARCHAR, pCzas INTERVAL DAY TO SECOND) IS
    BEGIN
        INSERT INTO DANIE(NAZWA, CZAS_PRZYGOTOWANIA, ID_DANIA)
        VALUES (pNazwa, pCzas, NVL((SELECT MAX(ID_DANIA)+1 FROM DANIE),1));
    END DodajDanie;
    Procedure ModyfikujDanie(pID NUMBER, pNazwa VARCHAR, pCzas INTERVAL DAY TO SECOND) IS
    BEGIN
        UPDATE DANIE
        SET NAZWA = pNazwa, CZAS_PRZYGOTOWANIA = pCzas
        WHERE ID_DANIA = pID;
    END ModyfikujDanie;
    Procedure UsunDanie(pID NUMBER) IS
    BEGIN
        DELETE
        FROM DANIE
        WHERE ID_DANIA = pID;
    END UsunDanie;
    Procedure DodajSkladnik(pNazwa VARCHAR, pDanie NUMBER, pIlosc NUMBER) IS
    BEGIN
        INSERT INTO SKLADNIK(ID_PRZEPISU, NAZWA, ILOSC)
        VALUES (pDanie,pNazwa,pIlosc);
    END DodajSkladnik;
    Procedure UsunSkladnik(pNazwa VARCHAR) IS
    BEGIN
        DELETE
        FROM SKLADNIK
        WHERE NAZWA = pNazwa;
    END UsunSkladnik;
    Procedure ZmienIloscSkladnika(pNazwa VARCHAR, pIlosc NUMBER) IS
    BEGIN
        UPDATE SKLADNIK
        SET ILOSC = ILOSC + pIlosc
        WHERE NAZWA = pNazwa;
    END ZmienIloscSkladnika;
    Procedure DodajSkrzynke(pProd VARCHAR, pNazwa VARCHAR, pIlosc NUMBER, pCena NUMBER) IS
    BEGIN
        INSERT INTO SKRZYNKA(PRODUCENT, NAZWA_PRODUKTU, CENA, ILOSC)
        VALUES (pProd,pNazwa,pCena,pIlosc);
    END DodajSkrzynke;
    Procedure Modyfikujskrzynke(pProd VARCHAR, pNazwa VARCHAR, pData DATE, pIlosc NUMBER, pCena NUMBER) IS
    BEGIN
        UPDATE SKRZYNKA
        SET ILOSC = pIlosc, CENA = pCena
        WHERE PRODUCENT = pProd AND NAZWA_PRODUKTU = pNazwa AND DATA = pData;
    END Modyfikujskrzynke;
    Procedure UsunSkrzynke(pProd VARCHAR, pNazwa VARCHAR, pData DATE) IS
    BEGIN
        DELETE
        FROM SKRZYNKA
        WHERE PRODUCENT = pProd AND NAZWA_PRODUKTU = pNazwa AND DATA = pData;
    END UsunSkrzynke;
    Procedure DodajUzupelnienie(pNazwa VARCHAR, pIlosc NUMBER) IS
    BEGIN
        INSERT INTO UZUPELNIENIE(NAZWA, ILOSC)
        VALUES (pNazwa,pIlosc);
    END DodajUzupelnienie;
    Procedure ZmienStatusUzupelnienia(pNazwa VARCHAR, pData DATE, pStan VARCHAR) IS
    BEGIN
        UPDATE UZUPELNIENIE
        SET STAN = pStan
        WHERE NAZWA = pNazwa AND DATA = pData;
    END ZmienStatusUzupelnienia;
    Procedure DodajPracownika(pImie VARCHAR, pNazwisko VARCHAR) IS
    BEGIN
        INSERT INTO PPRACOWNICY(ID_PRAC, IMIE, NAZWISKO)
        VALUES (NVL((SELECT MAX(ID_PRAC)+1 FROM PPRACOWNICY),1),pImie,pNazwisko);
    END DodajPracownika;
    Procedure ModyfikujPracownika(pID NUMBER, pImie VARCHAR, pNazwisko VARCHAR, pSG NUMBER) IS
    BEGIN
        UPDATE PPRACOWNICY
        SET IMIE = pImie, NAZWISKO = pNazwisko, STAWKA_GODZINOWA = pSG
        WHERE ID_PRAC = pID;
    END ModyfikujPracownika;
    Procedure ZmienStatusPracownika(pID NUMBER, pStan VARCHAR) IS
    BEGIN
        UPDATE PPRACOWNICY
        SET STAN = pStan
        WHERE ID_PRAC = pID;
    END ZmienStatusPracownika;
    Procedure UsunPracownika(pID NUMBER) IS
    BEGIN
        DELETE
        FROM PPRACOWNICY
        WHERE ID_PRAC = pID;
    END UsunPracownika;
    Procedure DodajBilans(pZysk NUMBER, pKoszt NUMBER) IS
    BEGIN
        INSERT INTO BILANS(KOSZT, ZYSK)
        VALUES (pKoszt, pZysk);
    END DodajBilans;
    Procedure ModyfikujBilans(pZysk NUMBER, pKoszt NUMBER) IS
    BEGIN
        UPDATE BILANS
        SET ZYSK = pZysk, KOSZT = pKoszt
        WHERE DATA = CURRENT_DATE;
    END ModyfikujBilans;
    Procedure ZacznijZmiane(pPrac NUMBER) IS
    BEGIN
        INSERT INTO FREKWENCJA(ID_PRAC,KONIEC_ZMIANY)
        VALUES (pPrac,null);
    END ZacznijZmiane;
    Procedure ZakonczZmiane(pPrac NUMBER, pCzas TIMESTAMP) IS
    BEGIN
        UPDATE FREKWENCJA
        SET KONIEC_ZMIANY = pCzas
        WHERE ID_PRAC = pPrac;
    END ZakonczZmiane;
END Procedury;
/

