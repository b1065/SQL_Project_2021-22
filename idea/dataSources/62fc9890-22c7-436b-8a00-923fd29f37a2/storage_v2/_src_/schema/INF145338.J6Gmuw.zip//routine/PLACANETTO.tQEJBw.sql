create FUNCTION PlacaNetto
 (pPlaca IN NUMBER,
  pPodatek IN NUMBER DEFAULT 20)
    RETURN NUMBER IS
    pNetto NUMBER;
BEGIN
    pNetto := pPlaca*(1-(pPodatek/100));
    RETURN pNetto;
END PlacaNetto;
/

