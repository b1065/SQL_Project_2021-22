create view PLACE (ID_ZESP, SREDNIA, MINIMUM, MAXIMUM, FUNDUSZ, L_PENSJI, L_DODATKOW) as
SELECT id_zesp, AVG(placa_pod+NVL(placa_dod,0)), MIN(placa_pod+NVL(placa_dod,0)), MAX(placa_pod+NVL(placa_dod,0)), SUM(placa_pod+NVL(placa_dod,0)),count(*), count(CASE WHEN placa_dod IS NOT NULL THEN 1 END)
FROM pracownicy NATURAL JOIN zespoly
GROUP BY id_zesp
/

