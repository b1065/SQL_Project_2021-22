create PACKAGE Funkcje IS
    FUNCTION ZnajdzFrekwencje(pID NUMBER) RETURN BOOLEAN;
END Funkcje;
/

