create PROCEDURE RaportKadrowy IS
BEGIN
    DBMS_OUTPUT.ENABLE(NULL);
    DECLARE
        CURSOR cPracownicy(vEtat VARCHAR) IS
            SELECT *
            FROM PRACOWNICY
            WHERE ETAT = vEtat
            ORDER BY NAZWISKO;
        CURSOR cEtaty IS
            SELECT *
            FROM ETATY
            ORDER BY NAZWA;
        vSrednia NUMBER(10,2) := 0;
        vHelp NUMBER(10,2);
        vIlosc NUMBER(2,0) := 0;
    BEGIN
        FOR vEtat IN cEtaty LOOP
            DBMS_OUTPUT.PUT_LINE('Etat:' || vEtat.NAZWA);
            DBMS_OUTPUT.PUT_LINE('------------------------------');
            FOR vPrac IN cPracownicy(vEtat.NAZWA) LOOP
                   vHelp := vPrac.PLACA_POD+NVL(vPrac.PLACA_DOD,0);
                   DBMS_OUTPUT.PUT_LINE(cPracownicy%ROWCOUNT || ' ' || vPrac.NAZWISKO || ', pensja: ' || vHelp);
                   vSrednia := vSrednia + vPrac.PLACA_POD + NVL(vPrac.PLACA_DOD,0);
                   vIlosc := vIlosc + 1;
            END LOOP;
            vSrednia := vSrednia/vIlosc;
            DBMS_OUTPUT.PUT_LINE('Liczba pracownikow: ' || vIlosc);
            DBMS_OUTPUT.PUT_LINE('Srednia pensja: ' || vSrednia);
            DBMS_OUTPUT.PUT_LINE(' ');
            vSrednia := 0;
            vIlosc := 0;
        END LOOP;
    END;
END;
/

