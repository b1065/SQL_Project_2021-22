create view SKLADNIKI_DLA_PRZEPISOW as
SELECT p.nazwa, (SELECT pr.nazwa FROM produkty pr WHERE s.id_produktu = pr.id_produktu) AS nazwapr
FROM przepisy p INNER JOIN skladniki_przepisow s ON p.id_przepisu = s.id_przepisu
GROUP BY p.nazwa, s.id_produktu
ORDER BY p.nazwa, nazwapr
/

