create PROCEDURE Podwyzka
 (pIdPrac IN NUMBER,
 pProcent IN NUMBER DEFAULT 10,
 pPensjaPoPodwyzce OUT NUMBER) IS
BEGIN
 UPDATE Pracownicy
 SET placa_pod = placa_pod * (1+pProcent/100)
 WHERE id_prac = pIdPrac
 RETURNING placa_pod INTO pPensjaPoPodwyzce;
END Podwyzka;
/

