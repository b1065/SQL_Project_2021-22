create PACKAGE Procedury IS
    PROCEDURE DodajKlienta(pImie VARCHAR, pNazwisko VARCHAR, pAdres VARCHAR);
    PROCEDURE UsunKlienta(pID NUMBER);
    PROCEDURE ModyfikujKlienta(pID NUMBER, pImie VARCHAR, pNazwisko VARCHAR, pAdres VARCHAR);
    PROCEDURE DodajZamowienie(pKlient NUMBER, pKoszt NUMBER, pCzas INTERVAL DAY TO SECOND);
    PROCEDURE ZmienStatusZamowienia(pID NUMBER, pStan VARCHAR);
    PROCEDURE DodajZadanie(pZam NUMBER, pDanie NUMBER, pPrac NUMBER);
    PROCEDURE ZmienStatusZadania(pZam NUMBER, pStan VARCHAR);
    PROCEDURE DodajDanie(pNazwa VARCHAR, pCzas INTERVAL DAY TO SECOND);
    PROCEDURE ModyfikujDanie(pID NUMBER, pNazwa VARCHAR, pCzas INTERVAL DAY TO SECOND);
    PROCEDURE UsunDanie(pID NUMBER);
    PROCEDURE DodajSkladnik(pNazwa VARCHAR, pDanie NUMBER, pIlosc NUMBER);
    PROCEDURE UsunSkladnik(pNazwa VARCHAR);
    PROCEDURE ZmienIloscSkladnika(pNazwa VARCHAR, pIlosc NUMBER);
    PROCEDURE DodajSkrzynke(pProd VARCHAR, pNazwa VARCHAR, pIlosc NUMBER, pCena NUMBER);
    PROCEDURE ModyfikujSkrzynke(pProd VARCHAR, pNazwa VARCHAR, pData DATE, pIlosc NUMBER, pCena NUMBER);
    PROCEDURE UsunSkrzynke(pProd VARCHAR, pNazwa VARCHAR, pData DATE);
    PROCEDURE DodajUzupelnienie(pNazwa VARCHAR, pIlosc NUMBER);
    PROCEDURE ZmienStatusUzupelnienia(pNazwa VARCHAR, pData DATE, pStan VARCHAR);
    PROCEDURE DodajPracownika(pImie VARCHAR, pNazwisko VARCHAR);
    PROCEDURE ModyfikujPracownika(pID NUMBER, pImie VARCHAR, pNazwisko VARCHAR, pSG NUMBER);
    PROCEDURE ZmienStatusPracownika(pID NUMBER, pStan VARCHAR);
    PROCEDURE UsunPracownika(pID NUMBER);
    PROCEDURE DodajBilans(pZysk NUMBER, pKoszt NUMBER);
    PROCEDURE ModyfikujBilans(pZysk NUMBER, pKoszt NUMBER);
    PROCEDURE ZacznijZmiane(pPrac NUMBER);
    PROCEDURE ZakonczZmiane(pPrac NUMBER, pCzas TIMESTAMP);
END Procedury;
/

