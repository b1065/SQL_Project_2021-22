create PACKAGE Zmienne IS
 PROCEDURE ZwiekszLicznik;
 PROCEDURE ZmniejszLicznik;
 FUNCTION PokazLicznik
    RETURN NATURAL;
END Zmienne;
/

