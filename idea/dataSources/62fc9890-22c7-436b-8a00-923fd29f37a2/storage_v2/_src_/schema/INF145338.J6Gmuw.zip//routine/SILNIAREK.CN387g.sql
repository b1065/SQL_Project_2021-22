create FUNCTION SilniaRek
 (pNumer IN NUMBER)
    RETURN NUMBER IS
    pWynik NUMBER;
BEGIN
    IF pNumer = 0 THEN
        RETURN 1;
    END IF;
    pWynik := pNumer*SilniaRek(pNumer-1);
    RETURN pWynik;
END SilniaRek;
/

