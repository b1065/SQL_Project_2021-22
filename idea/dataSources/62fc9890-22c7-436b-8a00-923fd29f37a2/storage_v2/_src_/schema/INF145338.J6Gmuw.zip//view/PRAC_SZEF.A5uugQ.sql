create view PRAC_SZEF (ID_PRAC, ID_SZEFA, PRACOWNIK, ETAT, SZEF) as
SELECT p.id_prac, p.id_szefa, p.nazwisko, p.etat,
(SELECT s.nazwisko FROM pracownicy s WHERE p.id_szefa = s.id_prac)
FROM pracownicy p
ORDER BY p.nazwisko
/

