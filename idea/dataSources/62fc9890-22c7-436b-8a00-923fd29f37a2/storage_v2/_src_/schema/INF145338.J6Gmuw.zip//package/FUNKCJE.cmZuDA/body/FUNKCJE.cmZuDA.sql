create PACKAGE BODY Funkcje IS
    FUNCTION ZnajdzFrekwencje(pID NUMBER) RETURN BOOLEAN IS
        pWynik BOOLEAN;
        pHelp TIMESTAMP;
    BEGIN
        SELECT POCZATEK_ZMIANY
        INTO pHelp
        FROM FREKWENCJA
        WHERE ID_PRAC = pID;
        CASE
            WHEN pHelp IS NULL THEN pWynik := FALSE;
            ELSE pWynik := TRUE;
        END CASE;
        RETURN pWynik;
    END ZnajdzFrekwencje;
END Funkcje;
/

