create PROCEDURE PokazPracownikowEtatu (etat VARCHAR) IS
BEGIN
    DBMS_OUTPUT.ENABLE(NULL);
    DECLARE CURSOR cPracownicy IS
    SELECT *
    FROM PRACOWNICY
    ORDER BY NAZWISKO;
    BEGIN
        FOR vPrac IN cPracownicy LOOP
            IF vPrac.ETAT = etat THEN
                DBMS_OUTPUT.PUT_LINE(vPrac.NAZWISKO);
            END IF;
        END LOOP;
    END;
END;
/

